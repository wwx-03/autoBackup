#该文件创建于2025年 03月 11日 星期二 15:16:52 CST
#!/bin/bash

printf "%-10s %-8s %-4s\n" 姓名 性别 体重kg
printf "%-10s %-8s %-4s\n" 小明 男 55.64
printf "%-10s %-8s %-4s\n" 小梁 男 43.768
printf "%-10s %-8s %-4s\n" 小亮 男 75.64


