#该文件创建于2025年 03月 12日 星期三 08:29:43 CST
#!/bin/bash

DemoFunn()
{
	echo "这是我Shell的第一个函数"
}

echo "------函数测试开始------"
DemoFunn
echo "------函数测试结束------"

AddFunn()
{
	echo "this function is used to add numbers."
	echo "please input the first number."
	read num1
	echo "please input the second number."
	read num2
	echo "the first num is $num1, and the second num is $num2"
	echo "they two are $(($num1 + $num2))"
}



AddFunn

FunnWithPara()
{
	echo "the first para is $1"
	echo "the first para is $2"
	echo "the first para is $3"
	echo "the first para is $4"
	echo "the first para is $5"
	echo "the first para is $6"
	echo "the first para is $7"
	echo "the first para is $8"
	echo "the first para is $9"
	echo "the first para is ${10}"
	echo "the first para is $10"
	echo "the first para is $#"
	echo "the first para is $*"
}

FunnWithPara 1 2 3 4 5 6 7 8 9 100 111

