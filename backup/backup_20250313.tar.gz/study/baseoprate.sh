#!/bin/bash

val=`expr 2 + 2`
echo "两数之和为: $val"

a=10
b=20

val=`expr $a + $b`
echo "a + b = $val"

val=`expr $a - $b`
echo "a - b = $val"

val=`expr $a \* $b`
echo "a * b = $val"

val=`expr $a / $b`
echo "a / b = $val"

val=`expr $a % $b`
echo "a % b = $val"

if [ $a == $b ]
then
	echo "a == b"
fi
if [ $a != $b ]
then
	echo "a != b"
fi

if [ $a -eq $b ]
then
	echo "a == b"
else
	echo "a != b"
fi
if [ $a -ne $b ]
then
	echo "a != b"
else
	echo "a == b"
fi
if [ $a -gt $b ]
then
	echo "a > b"
else
	echo "a < b"
fi
if [ $a -lt $b ]
then
	echo "a < b"
else
	echo "a > b"
fi
if [ $a -ge $b ]
then
	echo "a >= b"
else
	echo "a < b"
fi
if [ $a -le $b ]
then
	echo "a <= b"
else
	echo "a > b"
fi

if [ $a != $b ]
then
	echo "a != b >> return true"
else
	echo "a != b >> return false"
fi

if [ $a -gt 100 -a $b -lt 50 ]
then
	echo "a > 100 && b < 50 >> return true"
else
	echo "a > 100 && b < 50 >> return false"
fi

if [ $a -gt 100 -o $b -lt 50 ]
then 
	echo "a > 100 || b < 50 >> return true"
else
	echo "a > 100 || b < 50 >> return false"
fi

if [[ $a -gt 100 && $b -lt 50 ]]
then
	echo "return true"
else
	echo "return false"
fi

if [[ $a -gt 100 || $b -lt 50 ]]
then
	echo "return true"
else
	echo "return false"
fi

: '
字符串运算符, 假定 a 为 "abc", 变量 b 为 "efg"

运算符		说明

=		检测两个字符串是否相等, 相等返回true
!=		检测两个字符串是否不相等, 不相等返回true
-z		检测字符串长度是否为0, 为0返回true
-n		检测字符串长度是否不为0, 不为0返回true
$		检测字符串是否不为空, 不为空返回true

'

a="abc"
b="efg"
if [ $a = $b ]
then
	echo "$a = $b >> return true"
else
	echo "$a = $b >> return false"
fi

if [ $a != $b ]
then
	echo "$a != $b >> return true"
else
	echo "$a != $b >> return false"
fi

if [ -z $a ]
then
	echo "-z $a >> return true"
else
	echo "-z $a >> return false"
fi

if [ -n $a ]
then
	echo "-n $a >> return true"
else
	echo "-n $a >> return false"
fi

if [ $a ]
then 
	echo " $a >> return true"
else
	echo " $a >> return false"
fi

file="./test.sh"
if [ -r $file ]
then
	echo "\"$file\" this file can read."
else
	echo "\"$file\" this file can not read."
	chmod +r $file
	echo "now it can read."
fi

if [ -w $file ]
then
	echo "\"$file\" this file can write."
else
	echo "\"$file\" this file can not write."
fi

if [ -x $file ]
then
	echo "\"$file\" this file can excute."
else
	echo "\"$file\" this file can not excute"
fi


num=5

echo "initial-> num = $num"

let num++

echo "let num++ >> num = $num"

let num--

echo "let num-- >> num = $num"

num=$((num + 1))

echo "use \$(()) >> num = $num"

num=$((num - 1))

echo "use \$(()) >> num = $num"

((num++))
((num--))

echo "$num"


