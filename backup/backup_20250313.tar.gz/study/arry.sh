#!/bin/bash

echo "该文件用来学习Shell的数组"

echo "--- 定义一个数组,内容为 "A B "C" D""

myArry=(A B "C" D)

echo "--- 将数组元素逐个打印出来"

echo "第一个元素为: ${myArry[0]}"
echo "第二个元素为: ${myArry[1]}"
echo "第三个元素为: ${myArry[2]}"
echo "第四个元素为: ${myArry[3]}"

echo "--- 将数组元素全部打印出来, 使用到的相关符号 "* @" "

echo "数组的元素为: ${myArry[*]}"
echo "数组的元素为: ${myArry[@]}"

echo "--- 声明一个关联数组 相关命令: declare -A arry"

declare -A site=(["google"]="www.google.com" ["runoob"]="www.runoob.com" ["baidu"]="www.baidu.com")

echo "--- 访问关联数组可以使用指定的键,格式: arry["google"]"

echo "${site["google"]}"


echo "${site[*]}"

echo "${!site[*]}"

echo "${#site[*]}"

