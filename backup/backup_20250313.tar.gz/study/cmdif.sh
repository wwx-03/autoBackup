#该文件创建于2025年 03月 11日 星期二 16:14:47 CST
#!/bin/bash

a=10
b=20

if [ $a == $b ]
then
	echo "a == b"
elif [ $a -gt $b ]
then
	echo " a > b "
elif [ $a -lt $b ]
then
	echo " a < b "
else
	echo " none condition "
fi



