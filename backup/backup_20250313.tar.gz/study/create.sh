#!/bin/bash

echo "请输入文件名字"

read filename

if [ -e $filename ]
then
	echo "文件已存在"
else
	touch $filename
	echo "创建文件成功"
	chmod +x ./$filename
	echo -e "#该文件创建于`date`\r\n#!/bin/bash" > $filename
	vim $filename
fi


