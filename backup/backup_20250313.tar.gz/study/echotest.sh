#!/bin/bash

echo `date`


