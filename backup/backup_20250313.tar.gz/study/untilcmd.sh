#该文件创建于2025年 03月 11日 星期二 16:56:05 CST
#!/bin/bash

a=0

#a大于10结束循环
until [ ! $a -lt 10 ]
do
	echo $a
	a=`expr $a + 1`
done


