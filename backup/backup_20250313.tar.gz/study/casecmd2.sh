#该文件创建于2025年 03月 11日 星期二 17:06:31 CST
#!/bin/bash

site="google"

case $site in
"google")
	echo "www.google.com"
;;
"baidu")
	echo "www.baidu.com"
;;
"runoob")
	echo "www.runoob.com"
;;
esac



