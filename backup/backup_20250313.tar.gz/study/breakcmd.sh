#该文件创建于2025年 03月 12日 星期三 08:24:00 CST
#!/bin/bash

while :
do
	echo -n "输入1到5之间的数字"
	read ipt
	case $ipt in
		1|2|3|4|5)
			echo "你输入的数字为$ipt"
			;;
		*)
			echo "你输入的数字不是1到5之间, 游戏结束"
			break
			;;
	esac
done


