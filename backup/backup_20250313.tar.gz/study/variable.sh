#!/bin/bash
: '
"this is a test"
'


myString="runoob is a great site!"
echo ${myString}
echo ${#myString} #输出4
echo ${#myString[0]} #输出4
echo ${myString:1:4}

declare -i myInteger=4

echo "Hello World "$myString""

