#该文件创建于2025年 03月 11日 星期二 16:11:15 CST
#!/bin/bash

cd /bin

if test -e ./bash -o ./fffff
then
	echo "至少有一个文件存在"
else
	echo "两个文件都不存在"
fi



