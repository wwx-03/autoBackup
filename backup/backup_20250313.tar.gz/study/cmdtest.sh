#该文件创建于2025年 03月 11日 星期二 15:25:25 CST
#!/bin/bash
num1=100
num2=200
echo "定义两个数: num1, num2 >> num1=100 & num=200"
if test $num1 -eq $num2
then
	echo "两数相等"
else
	echo "两数不等"
fi

a=5
b=6

result=$[a+b]
echo "result = $result"

echo "--- 字符串测试 ---"

str1="ru1noob"
str2="runoob"

printf "定义两个字符串%-10s %-10s" str1 str2

if test $str1 = $str2
then
	echo '两个字符串相等'
else
	echo '两个字符串不相等'
fi

if test $str1 != $str2
then
	echo '两个字符串不相等'
else
	echo '两个字符串相等'
fi

if test -z $str1
then
	echo '字符串长度为0'
else
	echo '字符串长度不为0'
fi

if test -z $str2
then
	echo '字符串长度为0'
else
	echo '字符串长度不为0'
fi

if test -n $str1
then
	echo '字符串长度不为0'
else
	echo '字符串长度为0'
fi

if test -n $str2
then
	echo '字符串长度不为0'
else
	echo '字符串长度为0'
fi
