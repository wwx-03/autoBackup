#该文件创建于2025年 03月 11日 星期二 16:29:50 CST
#!/bin/bash

echo '按下 <CTRL+D> 退出'
echo '输入你最喜欢的网站'
while read SITE
do
	echo "$SITE 是一个好网站"
done


