#该文件创建于2025年 03月 11日 星期二 15:55:41 CST
#!/bin/bash

cd /bin

if test -e ./bash
then
	echo "文件已存在"
else
	echo "文件不存在"
fi


