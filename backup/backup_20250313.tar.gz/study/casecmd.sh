#该文件创建于2025年 03月 11日 星期二 17:01:38 CST
#!/bin/bash

read num

case $num in
1)
	printf "%-05d" $num
;;
2)
	echo "$num"
;;
*)
	echo "$num"
;;
esac




