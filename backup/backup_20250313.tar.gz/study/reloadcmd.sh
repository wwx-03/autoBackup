#该文件创建于2025年 03月 12日 星期三 09:04:22 CST
#!/bin/bash

echo "this is a test" > testfile
cat testfile

