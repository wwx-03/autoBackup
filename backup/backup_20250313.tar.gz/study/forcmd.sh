#该文件创建于2025年 03月 11日 星期二 16:27:33 CST
#!/bin/bash

for num in 1 2 3 4 5
do
	echo $num
done

for str in Hello World !
do
	echo $str
done


